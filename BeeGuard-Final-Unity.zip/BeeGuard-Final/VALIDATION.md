# Kết quả kiểm tra bản bàn giao

## Đã thực hiện

1. Unity Editor 6000.6.9f1 đã resolve các package, import project, biên dịch script và chuẩn hóa scene/prefab/AnimationClip bằng công cụ Editor trong project.
2. BeeGuardBuilder.ValidateAssets kiểm tra 12 prefab có BeeGuardActor và SpriteRenderer, cùng 9 clip legacy có thời lượng và curve binding hợp lệ. Log: BEE_ASSETS_PASS.
3. Build Standalone Linux64 thành công, Unity kết thúc mã 0. Log: BEE_BUILD_PASS.
4. Chạy chính file BeeGuard.x86_64 với --bee-smoke, thoát mã 0. Kiểm tra khởi tạo, thưởng, nâng cấp, hồi máu, từ chối mua ngoài Shop, chuẩn hóa di chuyển chéo, lướt, bắn, chuyển đợt, thắng, thua và chơi lại. Log: BEE_SMOKE_PASS.
5. Trên bản build, nạp 9 clip và sample Fly/Death để kiểm tra curve vị trí, scale, alpha, đồng thời xác nhận hoạt ảnh không thay đổi root dùng cho gameplay. Log: BEE_ANIMATION_PASS.
6. Chạy bản build có đồ họa OpenGL, chụp 5 màn hình. Tất cả ảnh được mở kiểm tra trực quan; đã sửa font tiếng Việt và nền nút sau lần kiểm tra đầu tiên. Các ảnh hiện tại là của bản cuối sau khi sửa. Log: BEE_VISUAL_PASS.
7. Chạy kiểm tra C# độc lập dùng đúng BeeGuardRules.cs: 1.027 assertion đạt, bao gồm 1.000 tình huống va chạm quét ngẫu nhiên, cửa hàng, giới hạn nâng cấp, hồi máu, công thức đợt và tốc độ bắn. Log: BEE_RULES_PASS.
8. Mở Preview_Animations.html bằng Chromium và kiểm tra 8 ảnh tải thành công, 9 nút chọn clip, tạm dừng, kéo timeline; không có lỗi JavaScript. Đây là kiểm tra trình xem keyframe, không thay thế kiểm tra Unity.

## Các dòng xác nhận

```
BEE_ASSETS_PASS
BEE_BUILD_PASS
BEE_ANIMATION_PASS: 9 clips loaded, transform and fade curves sampled, root unchanged
BEE_SMOKE_PASS: state, rewards, shop guard, movement, dash, projectiles, waves, victory, defeat, restart
BEE_VISUAL_PASS: five rendered screens captured
BEE_RULES_PASS: 1027 assertions (wave counts, shop, upgrades, healing, collision and 1000 randomized sweeps)
PREVIEW_PASS: 8 image loads, 9 clip selectors, pause and scrub, no JavaScript errors
```

## Phạm vi của bằng chứng

Các màn hình trong Screenshots là ảnh thật do bản build Unity xuất ra, ở các trạng thái do bài QA thiết lập để kiểm tra hiển thị. Màn Victory trong QA được kích hoạt bằng điều kiện kiểm tra, không phải bằng một phiên người chơi hoàn tất toàn trận. Chưa có đo FPS có kiểm soát, đánh giá cân bằng qua nhiều người chơi hoặc kiểm thử dài hạn. Các kiểm tra runtime gọi trực tiếp hàm gameplay; chưa tự động kiểm tra thao tác phím/chuột từ hệ điều hành.

Bản chạy đã kiểm tra là Linux x86_64. Windows, Android, WebGL và thiết bị khác chưa được build/kiểm thử. Các cảnh báo kết nối dịch vụ analytics của Unity không làm thất bại build; không có exception runtime hoặc tài nguyên thiếu trong hai lần chạy kiểm tra cuối.
