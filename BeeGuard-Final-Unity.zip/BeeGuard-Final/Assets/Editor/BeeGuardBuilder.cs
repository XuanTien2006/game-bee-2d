using System;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditor.Build.Reporting;
using UnityEngine;

public static class BeeGuardBuilder
{
    static readonly string[] Names={"GardenBackground","Hive","PlayerBee","EnemyBee","BomberBee","ArmoredBee","HoneyBullet","EnemyBullet","HoneyPickup","HealthPickup","Spark","Explosion"};
    [MenuItem("Bee Guard/Rebuild sprite prefabs")]
    public static void MakePrefabs()
    {
        BeeGuardAnimationBuilder.MakeClips();
        Directory.CreateDirectory("Assets/Resources/Prefabs");
        foreach(string name in Names)
        {
            string path="Assets/Resources/Art/"+name+".png";
            var importer=AssetImporter.GetAtPath(path) as TextureImporter;
            if(importer==null) throw new Exception("Missing art file: "+path);
            importer.textureType=TextureImporterType.Sprite; importer.spriteImportMode=SpriteImportMode.Single;
            importer.spritePixelsPerUnit=100; importer.alphaIsTransparency=true; importer.mipmapEnabled=false;
            importer.textureCompression=TextureImporterCompression.Uncompressed; importer.SaveAndReimport();
            Sprite sprite=AssetDatabase.LoadAssetAtPath<Sprite>(path);
            var go=new GameObject(name); var visual=new GameObject("Visual"); visual.transform.SetParent(go.transform,false);
            var renderer=visual.AddComponent<SpriteRenderer>(); renderer.sprite=sprite;
            renderer.sortingOrder=name=="GardenBackground"?-100:name=="Hive"?0:name=="Explosion"?30:10;
            float target=name=="Hive"?1.65f:name.Contains("Bullet")?.2f:name.Contains("Pickup")?.28f:name=="Spark"?.06f:name=="Explosion"?.8f:.85f;
            if(name=="GardenBackground")go.transform.localScale=new Vector3(12.8f/sprite.bounds.size.x,7.2f/sprite.bounds.size.y,1);
            else
            {
                go.transform.localScale=Vector3.one*(target/sprite.bounds.size.x);
                if(name!="Explosion" && name!="Spark") { var collider=go.AddComponent<CircleCollider2D>(); collider.isTrigger=true; collider.radius=(name=="Hive"?.48f:name.Contains("Bullet")?.06f:name.Contains("Pickup")?.12f:.23f)/go.transform.localScale.x; }
            }
            var animation=go.AddComponent<Animation>(); animation.playAutomatically=false;
            foreach(string clipName in new[]{"Fly","Shoot","Hit","Death","Dash","PickupFloat","HivePulse","Explosion","Collect"})
            {
                var clip=AssetDatabase.LoadAssetAtPath<AnimationClip>("Assets/Resources/Animations/"+clipName+".anim"); animation.AddClip(clip,clipName);
            }
            var actor=go.AddComponent<BeeGuardActor>(); actor.assetKey=name; actor.image=renderer; actor.animationPlayer=animation;
            PrefabUtility.SaveAsPrefabAsset(go,"Assets/Resources/Prefabs/"+name+".prefab"); UnityEngine.Object.DestroyImmediate(go);
        }
        AssetDatabase.SaveAssets();
    }
    static GameObject Place(string name,string label,Vector3 position,Transform parent=null)
    {
        var prefab=AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Resources/Prefabs/"+name+".prefab");
        var go=(GameObject)PrefabUtility.InstantiatePrefab(prefab); go.name=label; go.transform.position=position; if(parent!=null)go.transform.SetParent(parent); return go;
    }
    [MenuItem("Bee Guard/Prepare scene")]
    public static void Prepare()
    {
        // Explicit editor action: save your current scene before using this command.
        if(!Application.isBatchMode && !EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        MakePrefabs();
        var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
        var camera=new GameObject("Main Camera").AddComponent<Camera>(); camera.orthographic=true; camera.orthographicSize=3.6f; camera.tag="MainCamera";camera.transform.position=new Vector3(0,0,-10); camera.backgroundColor=new Color(.055f,.09f,.13f); camera.clearFlags=CameraClearFlags.SolidColor; camera.gameObject.AddComponent<AudioListener>();
        Place("GardenBackground","Garden Background",Vector3.zero); Place("Hive","Village Hive",new Vector3(0,-.17f,0)); Place("PlayerBee","Player",new Vector3(0,-1.5f,0));
        var preview=new GameObject("Enemy Preview • hidden during play");
        Place("EnemyBee","Purple enemy preview",new Vector3(-3,1.2f,0),preview.transform); Place("BomberBee","Bomber preview",new Vector3(3,1.2f,0),preview.transform); Place("ArmoredBee","Armored preview",new Vector3(4,-1,0),preview.transform);
        new GameObject("Game Manager").AddComponent<BeeGuardGame>();
        EditorSceneManager.SaveScene(scene,"Assets/Scenes/BeeGuard.unity");
        EditorBuildSettings.scenes=new[]{new EditorBuildSettingsScene("Assets/Scenes/BeeGuard.unity",true)};
        PlayerSettings.companyName="BeeGuard"; PlayerSettings.productName="Bee Guard"; PlayerSettings.defaultScreenWidth=1280; PlayerSettings.defaultScreenHeight=720; PlayerSettings.fullScreenMode=FullScreenMode.Windowed; AssetDatabase.SaveAssets();
    }
    [MenuItem("Bee Guard/Run gameplay checks in Play Mode")]
    public static void CheckGameplay()
    {
        if(!EditorApplication.isPlaying) { Debug.LogWarning("Enter Play Mode, then run this command."); return; }
        var game=UnityEngine.Object.FindAnyObjectByType<BeeGuardGame>(); if(game!=null)game.RunSmoke();
    }
    public static void ValidateAssets()
    {
        foreach(string name in Names)
        {
            var prefab=AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Resources/Prefabs/"+name+".prefab");
            if(prefab==null || prefab.GetComponent<BeeGuardActor>()==null || prefab.GetComponentInChildren<SpriteRenderer>()==null)throw new Exception("Invalid prefab: "+name);
        }
        foreach(string name in new[]{"Fly","Shoot","Hit","Death","Dash","PickupFloat","HivePulse","Explosion","Collect"})
        {
            var clip=AssetDatabase.LoadAssetAtPath<AnimationClip>("Assets/Resources/Animations/"+name+".anim");
            if(clip==null || !clip.legacy || clip.length<=0 || AnimationUtility.GetCurveBindings(clip).Length==0)throw new Exception("Invalid clip: "+name);
        }
        Debug.Log("BEE_ASSETS_PASS");
    }
    public static void BuildLinux() { Build(BuildTarget.StandaloneLinux64,"Builds/Linux/BeeGuard.x86_64"); }
    public static void BuildWindows() { Build(BuildTarget.StandaloneWindows64,"Builds/Windows/BeeGuard.exe"); }
    static void Build(BuildTarget target,string fallback)
    {
        Prepare(); ValidateAssets(); string destination=Environment.GetEnvironmentVariable("BEE_BUILD_PATH") ?? fallback;
        Directory.CreateDirectory(Path.GetDirectoryName(destination));
        var report=BuildPipeline.BuildPlayer(new BuildPlayerOptions{scenes=new[]{"Assets/Scenes/BeeGuard.unity"},locationPathName=destination,target=target,options=BuildOptions.None});
        if(report.summary.result!=BuildResult.Succeeded)throw new Exception("Build failed: "+report.summary.result); Debug.Log("BEE_BUILD_PASS");
    }
}
