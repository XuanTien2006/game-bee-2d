using UnityEngine;
using UnityEditor;
using System.IO;
public static class BeeGuardAnimationBuilder
{
    static AnimationClip clip;
    static void Begin(string name,bool loop) { clip=new AnimationClip {name=name,legacy=true,frameRate=60,wrapMode=loop?WrapMode.Loop:WrapMode.Once}; }
    static void Track(string property,System.Type type,params float[] values)
    {
        var keys=new Keyframe[values.Length/2];
        for(int i=0;i<keys.Length;i++)keys[i]=new Keyframe(values[i*2],values[i*2+1],0,0);
        AnimationUtility.SetEditorCurve(clip,EditorCurveBinding.FloatCurve("Visual",type,property),new AnimationCurve(keys));
    }
    static void Save()
    {
        string path="Assets/Resources/Animations/"+clip.name+".anim";
        var old=AssetDatabase.LoadAssetAtPath<AnimationClip>(path);
        if(old==null)AssetDatabase.CreateAsset(clip,path); else { EditorUtility.CopySerialized(clip,old); EditorUtility.SetDirty(old); UnityEngine.Object.DestroyImmediate(clip); }
    }
    [MenuItem("Bee Guard/Rebuild animation clips")]
    public static void MakeClips()
    {
        Directory.CreateDirectory("Assets/Resources/Animations");
        Begin("Fly",true);
        Track("m_LocalPosition.x",typeof(Transform),0f,0f,0.15f,0f,0.3f,0f,0.45f,0f,0.6f,0f);
        Track("m_LocalPosition.y",typeof(Transform),0f,0f,0.15f,0.25f,0.3f,0f,0.45f,-0.25f,0.6f,0f);
        Track("m_LocalPosition.z",typeof(Transform),0f,0f,0.15f,0f,0.3f,0f,0.45f,0f,0.6f,0f);
        Track("m_LocalScale.x",typeof(Transform),0f,1f,0.15f,1.025f,0.3f,1f,0.45f,0.975f,0.6f,1f);
        Track("m_LocalScale.y",typeof(Transform),0f,1f,0.15f,0.975f,0.3f,1f,0.45f,1.025f,0.6f,1f);
        Track("m_LocalScale.z",typeof(Transform),0f,1f,0.15f,1f,0.3f,1f,0.45f,1f,0.6f,1f);
        Track("localEulerAnglesRaw.x",typeof(Transform),0f,0f,0.3f,0f,0.6f,0f);
        Track("localEulerAnglesRaw.y",typeof(Transform),0f,0f,0.3f,0f,0.6f,0f);
        Track("localEulerAnglesRaw.z",typeof(Transform),0f,-3f,0.3f,3f,0.6f,-3f);
        Save();
        Begin("Shoot",false);
        Track("m_LocalPosition.x",typeof(Transform),0f,0f,0.035f,-0.25f,0.12f,0f);
        Track("m_LocalPosition.y",typeof(Transform),0f,0f,0.035f,0f,0.12f,0f);
        Track("m_LocalPosition.z",typeof(Transform),0f,0f,0.035f,0f,0.12f,0f);
        Track("m_LocalScale.x",typeof(Transform),0f,1f,0.035f,0.86f,0.12f,1f);
        Track("m_LocalScale.y",typeof(Transform),0f,1f,0.035f,1.12f,0.12f,1f);
        Track("m_LocalScale.z",typeof(Transform),0f,1f,0.035f,1f,0.12f,1f);
        Save();
        Begin("Hit",false);
        Track("m_LocalScale.x",typeof(Transform),0f,1f,0.05f,1.2f,0.12f,0.9f,0.2f,1f);
        Track("m_LocalScale.y",typeof(Transform),0f,1f,0.05f,0.78f,0.12f,1.13f,0.2f,1f);
        Track("m_LocalScale.z",typeof(Transform),0f,1f,0.05f,1f,0.12f,1f,0.2f,1f);
        Track("localEulerAnglesRaw.x",typeof(Transform),0f,0f,0.05f,0f,0.12f,0f,0.2f,0f);
        Track("localEulerAnglesRaw.y",typeof(Transform),0f,0f,0.05f,0f,0.12f,0f,0.2f,0f);
        Track("localEulerAnglesRaw.z",typeof(Transform),0f,0f,0.05f,-10f,0.12f,8f,0.2f,0f);
        Save();
        Begin("Death",false);
        Track("m_LocalPosition.x",typeof(Transform),0f,0f,0.12f,0f,0.42f,0f);
        Track("m_LocalPosition.y",typeof(Transform),0f,0f,0.12f,0.3f,0.42f,-1.2f);
        Track("m_LocalPosition.z",typeof(Transform),0f,0f,0.12f,0f,0.42f,0f);
        Track("m_LocalScale.x",typeof(Transform),0f,1f,0.42f,0.15f);
        Track("m_LocalScale.y",typeof(Transform),0f,1f,0.42f,0.15f);
        Track("m_LocalScale.z",typeof(Transform),0f,1f,0.42f,1f);
        Track("localEulerAnglesRaw.x",typeof(Transform),0f,0f,0.42f,0f);
        Track("localEulerAnglesRaw.y",typeof(Transform),0f,0f,0.42f,0f);
        Track("localEulerAnglesRaw.z",typeof(Transform),0f,0f,0.42f,160f);
        Track("m_Color.a",typeof(SpriteRenderer),0f,1f,0.15f,1f,0.42f,0f);
        Save();
        Begin("Dash",false);
        Track("m_LocalScale.x",typeof(Transform),0f,1f,0.045f,1.45f,0.18f,1f);
        Track("m_LocalScale.y",typeof(Transform),0f,1f,0.045f,0.7f,0.18f,1f);
        Track("m_LocalScale.z",typeof(Transform),0f,1f,0.045f,1f,0.18f,1f);
        Save();
        Begin("PickupFloat",true);
        Track("m_LocalPosition.x",typeof(Transform),0f,0f,0.55f,0f,1.1f,0f);
        Track("m_LocalPosition.y",typeof(Transform),0f,0f,0.55f,0.3f,1.1f,0f);
        Track("m_LocalPosition.z",typeof(Transform),0f,0f,0.55f,0f,1.1f,0f);
        Track("m_LocalScale.x",typeof(Transform),0f,1f,0.55f,1.12f,1.1f,1f);
        Track("m_LocalScale.y",typeof(Transform),0f,1f,0.55f,1.12f,1.1f,1f);
        Track("m_LocalScale.z",typeof(Transform),0f,1f,0.55f,1f,1.1f,1f);
        Save();
        Begin("HivePulse",true);
        Track("m_LocalScale.x",typeof(Transform),0f,1f,0.9f,1.025f,1.8f,1f);
        Track("m_LocalScale.y",typeof(Transform),0f,1f,0.9f,1.025f,1.8f,1f);
        Track("m_LocalScale.z",typeof(Transform),0f,1f,0.9f,1f,1.8f,1f);
        Save();
        Begin("Explosion",false);
        Track("m_LocalScale.x",typeof(Transform),0f,0.1f,0.09f,1.1f,0.4f,1.8f);
        Track("m_LocalScale.y",typeof(Transform),0f,0.1f,0.09f,1.1f,0.4f,1.8f);
        Track("m_LocalScale.z",typeof(Transform),0f,1f,0.09f,1f,0.4f,1f);
        Track("m_Color.a",typeof(SpriteRenderer),0f,1f,0.12f,0.85f,0.4f,0f);
        Save();
        Begin("Collect",false);
        Track("m_LocalPosition.x",typeof(Transform),0f,0f,0.22f,0f);
        Track("m_LocalPosition.y",typeof(Transform),0f,0f,0.22f,1f);
        Track("m_LocalPosition.z",typeof(Transform),0f,0f,0.22f,0f);
        Track("m_LocalScale.x",typeof(Transform),0f,1f,0.08f,1.3f,0.22f,0.15f);
        Track("m_LocalScale.y",typeof(Transform),0f,1f,0.08f,1.3f,0.22f,0.15f);
        Track("m_LocalScale.z",typeof(Transform),0f,1f,0.08f,1f,0.22f,1f);
        Track("m_Color.a",typeof(SpriteRenderer),0f,1f,0.08f,1f,0.22f,0f);
        Save();
        AssetDatabase.SaveAssets();
    }
}
