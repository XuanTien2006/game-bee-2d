using System;

// Engine-independent rules shared by gameplay and the executable checks.
public static class BeeGuardRules
{
    public const int FinalWave=5;
    public static int EnemyCount(int wave) { if(wave<1 || wave>FinalWave)throw new ArgumentOutOfRangeException(nameof(wave)); return 5+wave*3; }
    public static int UpgradeCost(int level) { return 45+level*30; }
    public static int Damage(int level) { return 24+level*12; }
    public static float FireInterval(int level) { return .25f/(1+level*.3f); }
    public static float SegmentDistance(float px,float py,float ax,float ay,float bx,float by)
    {
        float dx=bx-ax,dy=by-ay; float length=dx*dx+dy*dy;
        float t=length<=.000001f?0:Math.Max(0,Math.Min(1,((px-ax)*dx+(py-ay)*dy)/length));
        float x=px-ax-t*dx,y=py-ay-t*dy; return (float)Math.Sqrt(x*x+y*y);
    }
    // Swept circle collision: entry time on [0,1], or positive infinity.
    public static float ImpactTime(float px,float py,float ax,float ay,float bx,float by,float radius)
    {
        float dx=bx-ax,dy=by-ay,fx=ax-px,fy=ay-py;
        float c=fx*fx+fy*fy-radius*radius; if(c<=0)return 0;
        float a=dx*dx+dy*dy; if(a<.000001f)return float.PositiveInfinity;
        float b=2*(fx*dx+fy*dy),disc=b*b-4*a*c; if(disc<0)return float.PositiveInfinity;
        float t=(-b-(float)Math.Sqrt(disc))/(2*a); return t>=0 && t<=1?t:float.PositiveInfinity;
    }
    public static bool TryBuy(int type,ref int coins,ref int damageLevel,ref int rateLevel,ref float health,ref float hive)
    {
        if(type<0 || type>3)return false;
        int cost=type==0?UpgradeCost(damageLevel):type==1?UpgradeCost(rateLevel):type==2?35:40;
        if(coins<cost || (type==0 && damageLevel>=4) || (type==1 && rateLevel>=4) || (type==2 && health>=100) || (type==3 && hive>=100))return false;
        coins-=cost; if(type==0)damageLevel++; else if(type==1)rateLevel++; else if(type==2)health=Math.Min(100,health+40); else hive=Math.Min(100,hive+35); return true;
    }
}
