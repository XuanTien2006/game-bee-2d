using System.Collections.Generic;
using UnityEngine;

public sealed partial class BeeGuardGame
{
    BeeGuardActor playerView, hiveView;
    Transform dynamicRoot;
    readonly Dictionary<object, BeeGuardActor> views = new Dictionary<object, BeeGuardActor>();
    readonly HashSet<object> visible = new HashSet<object>();
    readonly List<object> stale = new List<object>();
    readonly Dictionary<string, GameObject> prefabCache = new Dictionary<string, GameObject>();
    static Vector3 World(Vector2 p) { return new Vector3((p.x-640)/100f, (360-p.y)/100f, 0); }
    BeeGuardActor Make(string asset, Transform parent=null)
    {
        GameObject prefab;
        if(!prefabCache.TryGetValue(asset,out prefab)) { prefab=Resources.Load<GameObject>("Prefabs/"+asset); prefabCache[asset]=prefab; }
        if(prefab==null) { Debug.LogError("Missing prefab: "+asset); enabled=false; return null; }
        var go=Instantiate(prefab,parent); var actor=go.GetComponent<BeeGuardActor>();
        if(actor==null) { Debug.LogError("Missing BeeGuardActor on "+asset); Destroy(go); enabled=false; }
        return actor;
    }
    void InitializeSpriteWorld()
    {
        var camera=Camera.main;
        camera.orthographic=true; camera.orthographicSize=3.6f; camera.aspect=16f/9f;
        camera.transform.position=new Vector3(0,0,-10);
        if(camera.GetComponent<AudioListener>()==null) camera.gameObject.AddComponent<AudioListener>();
        if(GameObject.Find("Garden Background")==null) { var r=Make("GardenBackground"); if(r!=null)r.name="Garden Background"; }
        var obj=GameObject.Find("Player"); playerView=obj!=null?obj.GetComponent<BeeGuardActor>():Make("PlayerBee");
        obj=GameObject.Find("Village Hive"); hiveView=obj!=null?obj.GetComponent<BeeGuardActor>():Make("Hive");
        if(playerView!=null) { playerView.name="Player"; playerView.transform.position=World(new Vector2(640,510)); }
        if(hiveView!=null) { hiveView.name="Village Hive"; hiveView.transform.position=World(hive); }
        if(playerView==null || hiveView==null) { Debug.LogError("Scene missing animated actors. Use Bee Guard > Prepare scene."); enabled=false; return; }
        dynamicRoot=new GameObject("Runtime • Enemies Bullets Loot Effects").transform;
        var previews=GameObject.Find("Enemy Preview • hidden during play"); if(previews!=null)previews.SetActive(false);
    }
    void ClearSpriteViews()
    {
        if(dynamicRoot!=null)foreach(Transform child in dynamicRoot) { child.gameObject.SetActive(false); Destroy(child.gameObject); }
        views.Clear(); visible.Clear(); stale.Clear();
        if(playerView!=null)playerView.Revive(); if(hiveView!=null)hiveView.Revive();
    }
    void Animate(object key,string clip,int priority) { BeeGuardActor actor; if(views.TryGetValue(key,out actor) && actor!=null)actor.PlayAction(clip,priority); }
    void Explosion(Vector2 p,Color color)
    {
        var actor=Make("Explosion",dynamicRoot); if(actor!=null) { actor.transform.position=World(p); actor.Explode(color); } Burst(p,color);
    }
    void LateUpdate()
    {
        if(playerView==null || hiveView==null || dynamicRoot==null)return;
        playerView.transform.position=World(phase==Phase.Menu?new Vector2(450,500):player);
        playerView.Flip(phase!=Phase.Menu && mouse.x<player.x);
        if(phase!=Phase.Defeat)playerView.Show(immunity<=0 || Mathf.Sin(Time.time*40)>0);
        hiveView.transform.position=World(hive);
        visible.Clear();
        foreach(Enemy e in enemies)
        {
            var actor=View(e,e.kind==1?"BomberBee":e.kind==2?"ArmoredBee":"EnemyBee");
            if(actor!=null) { actor.transform.position=World(e.p); actor.Flip((e.kind==1?player.x:hive.x)<e.p.x); }
        }
        foreach(Shot s in shots)
        {
            var actor=View(s,s.hostile?"EnemyBullet":"HoneyBullet");
            if(actor!=null) { actor.transform.position=World(s.p); actor.transform.rotation=Quaternion.Euler(0,0,Mathf.Atan2(-s.velocity.y,s.velocity.x)*Mathf.Rad2Deg); }
        }
        foreach(Loot l in loot) { var actor=View(l,l.heal?"HealthPickup":"HoneyPickup"); if(actor!=null)actor.transform.position=World(l.p); }
        foreach(Spark s in sparks) { var actor=View(s,"Spark"); if(actor!=null) { actor.transform.position=World(s.p); actor.SetTint(new Color(s.color.r,s.color.g,s.color.b,Mathf.Clamp01(s.life/.4f))); } }
        stale.Clear(); foreach(var pair in views)if(!visible.Contains(pair.Key))stale.Add(pair.Key);
        foreach(object key in stale)
        {
            BeeGuardActor actor=views[key];
            if(actor!=null) { if(key is Enemy || key is Loot)actor.RemoveAnimated(); else Destroy(actor.gameObject); }
            views.Remove(key);
        }
    }
    BeeGuardActor View(object key,string asset)
    {
        visible.Add(key); BeeGuardActor actor;
        if(!views.TryGetValue(key,out actor)) { actor=Make(asset,dynamicRoot); if(actor!=null) { actor.name=asset; views.Add(key,actor); } }
        return actor;
    }
}
