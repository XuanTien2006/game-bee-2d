using UnityEngine;

// Animation changes only the Visual child. Combat moves the root independently.
[DisallowMultipleComponent]
public sealed class BeeGuardActor : MonoBehaviour
{
    public string assetKey;
    public SpriteRenderer image;
    public Animation animationPlayer;
    string idleClip;
    float transientUntil, flashUntil;
    int priority;
    Color tint=Color.white;
    bool dying;
    static readonly string[] Clips={"Fly","Shoot","Hit","Death","Dash","PickupFloat","HivePulse","Explosion","Collect"};
    void Awake()
    {
        if(image==null) image=GetComponentInChildren<SpriteRenderer>();
        if(animationPlayer==null) animationPlayer=GetComponent<Animation>();
        if(animationPlayer==null) animationPlayer=gameObject.AddComponent<Animation>();
        animationPlayer.playAutomatically=false;
        foreach(string name in Clips)
        {
            var clip=Resources.Load<AnimationClip>("Animations/"+name);
            if(clip!=null && animationPlayer.GetClip(name)==null) animationPlayer.AddClip(clip,name);
        }
        idleClip=assetKey=="Hive"?"HivePulse":assetKey.Contains("Pickup")?"PickupFloat":assetKey.EndsWith("Bee")?"Fly":null;
        if(idleClip!=null) animationPlayer.Play(idleClip);
    }
    void Update()
    {
        if(dying) return;
        if(priority>0 && Time.time>=transientUntil) { priority=0; if(idleClip!=null) animationPlayer.Play(idleClip); else ResetVisual(); }
        if(image!=null) image.color=Time.time<flashUntil?new Color(1f,.45f,.4f,tint.a):tint;
    }
    void ResetVisual()
    {
        if(image==null) return;
        image.transform.localPosition=Vector3.zero; image.transform.localRotation=Quaternion.identity; image.transform.localScale=Vector3.one;
    }
    public void SetTint(Color color) { tint=color; if(image!=null && Time.time>=flashUntil) image.color=tint; }
    public void Flip(bool left) { if(image!=null) image.flipX=left; }
    public void Show(bool show) { if(image!=null) image.enabled=show; }
    public void PlayAction(string clipName,int importance=1)
    {
        if(dying || (priority>importance && Time.time<transientUntil)) return;
        var clip=animationPlayer.GetClip(clipName); if(clip==null) return;
        priority=importance; transientUntil=Time.time+clip.length;
        animationPlayer.Stop(); ResetVisual(); animationPlayer.Play(clipName);
        if(clipName=="Hit") flashUntil=Time.time+.15f;
    }
    public void RemoveAnimated()
    {
        if(dying) return; dying=true;
        foreach(var collider in GetComponents<Collider2D>()) collider.enabled=false;
        animationPlayer.Stop(); ResetVisual(); string effect=assetKey.Contains("Pickup")?"Collect":"Death"; var clip=animationPlayer.GetClip(effect);
        if(clip!=null) { animationPlayer.Play(effect); Destroy(gameObject,clip.length); } else Destroy(gameObject);
    }
    public void Revive()
    {
        dying=false; priority=0; flashUntil=0; tint=Color.white;
        if(animationPlayer!=null)animationPlayer.Stop(); ResetVisual();
        if(image!=null) { image.color=Color.white; image.enabled=true; }
        foreach(var collider in GetComponents<Collider2D>())collider.enabled=true;
        if(animationPlayer!=null && idleClip!=null)animationPlayer.Play(idleClip);
    }
    public void Fall()
    {
        if(dying)return; animationPlayer.Stop(); ResetVisual(); dying=true; if(image!=null)image.enabled=true; animationPlayer.Play("Death");
    }
    public void Explode(Color color)
    {
        tint=color; if(image!=null)image.color=color;
        animationPlayer.Stop(); var clip=animationPlayer.GetClip("Explosion");
        if(clip!=null) { dying=true; animationPlayer.Play("Explosion"); Destroy(gameObject,clip.length); } else Destroy(gameObject,.4f);
    }
}
