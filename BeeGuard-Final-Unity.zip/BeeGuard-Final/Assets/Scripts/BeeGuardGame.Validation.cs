using System;
using System.Collections;
using System.IO;
using UnityEngine;

public sealed partial class BeeGuardGame
{
    bool runningChecks;
    void ValidateAnimations()
    {
        foreach(string name in new[]{"Fly","Shoot","Hit","Death","Dash","PickupFloat","HivePulse","Explosion","Collect"})
        {
            var clip=Resources.Load<AnimationClip>("Animations/"+name);
            if(clip==null || !clip.legacy || clip.length<=0)throw new Exception("Animation asset: "+name);
        }
        Vector3 rootBefore=playerView.transform.position;
        Resources.Load<AnimationClip>("Animations/Fly").SampleAnimation(playerView.gameObject,.15f);
        if(Mathf.Abs(playerView.image.transform.localPosition.y-.25f)>.005f)throw new Exception("Fly position curve");
        if(Mathf.Abs(playerView.image.transform.localScale.x-1.025f)>.005f)throw new Exception("Fly scale curve");
        Resources.Load<AnimationClip>("Animations/Death").SampleAnimation(playerView.gameObject,.42f);
        if(playerView.image.color.a>.01f)throw new Exception("Death alpha curve");
        if(Vector3.Distance(rootBefore,playerView.transform.position)>.0001f)throw new Exception("Animation changed combat root");
        playerView.Revive(); Debug.Log("BEE_ANIMATION_PASS: 9 clips loaded, transform and fade curves sampled, root unchanged");
    }
    IEnumerator CaptureView(string path)
    {
        if(File.Exists(path))File.Delete(path);
        yield return new WaitForEndOfFrame(); ScreenCapture.CaptureScreenshot(path);
        float end=Time.realtimeSinceStartup+8;
        while(!File.Exists(path) && Time.realtimeSinceStartup<end)yield return null;
        if(!File.Exists(path)) { Debug.LogError("Screenshot timeout: "+path); Application.Quit(1); }
    }
    IEnumerator RunVisualCheck()
    {
        runningChecks=true;
        string folder=Environment.GetEnvironmentVariable("BEE_SCREENSHOT_DIR");
        if(string.IsNullOrEmpty(folder))folder=Path.Combine(Application.persistentDataPath,"Screenshots");
        Directory.CreateDirectory(folder); Screen.SetResolution(1280,720,FullScreenMode.Windowed);
        yield return new WaitForSeconds(.7f);
        ValidateAnimations();
        phase=Phase.Menu; yield return new WaitForSeconds(.3f); yield return CaptureView(Path.Combine(folder,"01_Menu.png"));
        StartGame(); wave=3; remaining=9;
        for(int i=0;i<6;i++) { Spawn(); remaining--; }
        yield return new WaitForSeconds(.8f); mouse=player+Vector2.right*200; Fire();
        yield return new WaitForSeconds(.05f); yield return CaptureView(Path.Combine(folder,"02_Battle.png"));
        enemies.Clear(); remaining=0; phase=Phase.Shop; coins=180; hp=74; hiveHP=82; shots.Clear(); yield return new WaitForSeconds(.3f); yield return CaptureView(Path.Combine(folder,"03_Shop.png"));
        wave=5; phase=Phase.Battle; Finish(true); yield return new WaitForSeconds(.3f); yield return CaptureView(Path.Combine(folder,"04_Victory.png"));
        phase=Phase.Battle; hp=0; Finish(false); yield return new WaitForSeconds(.5f); yield return CaptureView(Path.Combine(folder,"05_Defeat.png"));
        Debug.Log("BEE_VISUAL_PASS: five rendered screens captured"); Application.Quit(0);
    }
}
