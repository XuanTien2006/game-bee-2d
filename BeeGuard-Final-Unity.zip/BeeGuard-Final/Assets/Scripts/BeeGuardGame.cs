using System;
using System.Collections.Generic;
using UnityEngine;

// A self-contained 2D arena game. Coordinates use a 1280 x 720 virtual canvas.
public sealed partial class BeeGuardGame : MonoBehaviour
{
    enum Phase { Menu, Battle, Shop, Victory, Defeat }
    sealed class Enemy { public Vector2 p; public float hp, speed, attack; public int kind; }
    sealed class Shot { public Vector2 p, velocity; public float life; public bool hostile; }
    sealed class Spark { public Vector2 p, v; public float life; public Color color; }
    sealed class Loot { public Vector2 p; public float life = 12; public bool heal; }
    readonly List<Enemy> enemies = new List<Enemy>();
    readonly List<Shot> shots = new List<Shot>();
    readonly List<Spark> sparks = new List<Spark>();
    readonly List<Loot> loot = new List<Loot>();
    readonly Vector2 hive = new Vector2(640, 377);
    Vector2 player, mouse;
    Phase phase;
    Texture2D disc, white;
    GUIStyle heading, label, small, button;
    int wave, remaining, coins, kills, damageLevel, rateLevel, best;
    float hp, hiveHP, spawnClock, fireClock, immunity, dashClock, dashTime, elapsed;
    bool paused, muted;
    AudioSource audioSource;
    AudioClip shootSound, hitSound, rewardSound;
    const int FinalWave = BeeGuardRules.FinalWave;
    float waveBanner;
    static readonly Color Ink = new Color(.055f,.09f,.13f);
    static readonly Color Honey = new Color(1f,.76f,.24f);
    static readonly Color Mint = new Color(.42f,.92f,.72f);
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void Boot() { if (FindAnyObjectByType<BeeGuardGame>() == null) new GameObject("Bee Guard • Game").AddComponent<BeeGuardGame>(); }
    void Awake()
    {
        Application.targetFrameRate = 60;
        if(Camera.main==null) { var cam=new GameObject("Main Camera").AddComponent<Camera>(); cam.tag="MainCamera"; cam.orthographic=true; cam.clearFlags=CameraClearFlags.SolidColor; cam.backgroundColor=Ink; }
        white = Texture2D.whiteTexture;
        disc = new Texture2D(64,64,TextureFormat.RGBA32,false);
        for(int y=0;y<64;y++) for(int x=0;x<64;x++) { float a=Mathf.Clamp01(32f-Vector2.Distance(new Vector2(x+.5f,y+.5f),new Vector2(32,32))); disc.SetPixel(x,y,new Color(1,1,1,a)); }
        disc.Apply();
        audioSource=gameObject.AddComponent<AudioSource>();
        shootSound=Tone(680,.06f); hitSound=Tone(140,.12f); rewardSound=Tone(1040,.16f);
        best=PlayerPrefs.GetInt("BeeGuardBest",0);
        phase=Phase.Menu;
        muted=PlayerPrefs.GetInt("BeeGuardMuted",0)!=0;
        InitializeSpriteWorld();
        if(Array.IndexOf(Environment.GetCommandLineArgs(),"--bee-smoke")>=0) RunSmoke();
        if(Array.IndexOf(Environment.GetCommandLineArgs(),"--bee-visual-check")>=0)StartCoroutine(RunVisualCheck());
    }
    AudioClip Tone(float frequency,float duration)
    {
        int n=(int)(22050*duration); float[] samples=new float[n];
        for(int i=0;i<n;i++) samples[i]=Mathf.Sin(i*frequency*2*Mathf.PI/22050)*.12f*(1f-(float)i/n);
        var clip=AudioClip.Create("Procedural tone",n,1,22050,false); clip.SetData(samples,0); return clip;
    }
    void Sound(AudioClip clip) { if(!muted) audioSource.PlayOneShot(clip); }
    void StartGame()
    {
        ClearSpriteViews(); SetPaused(false);
        enemies.Clear(); shots.Clear(); sparks.Clear(); loot.Clear();
        player=new Vector2(640,510); hp=hiveHP=100; coins=kills=damageLevel=rateLevel=0;
        wave=0; elapsed=0; dashClock=0; immunity=0; fireClock=0; dashTime=0; paused=false; NextWave();
    }
    void NextWave() { wave++; remaining=BeeGuardRules.EnemyCount(wave); spawnClock=.6f; shots.Clear(); phase=Phase.Battle; waveBanner=2; }
    void SetPaused(bool value) { paused=value; Time.timeScale=value?0:1; }
    void DamagePlayer(float amount)
    {
        if(immunity>0)return; hp=Mathf.Max(0,hp-amount); immunity=.7f;
        if(playerView!=null)playerView.PlayAction("Hit",3); Burst(player,new Color(1,.3f,.35f)); Sound(hitSound);
    }
    void DamageHive(float amount) { hiveHP=Mathf.Max(0,hiveHP-amount); if(hiveView!=null)hiveView.PlayAction("Hit",3); Sound(hitSound); }
    void Update()
    {
        mouse=new Vector2(Input.mousePosition.x/Screen.width*1280,(1-Input.mousePosition.y/Screen.height)*720);
        if(Input.GetKeyDown(KeyCode.M)) { muted=!muted; PlayerPrefs.SetInt("BeeGuardMuted",muted?1:0); }
        if(Input.GetKeyDown(KeyCode.Escape) && phase==Phase.Battle) SetPaused(!paused);
        Cursor.visible=phase!=Phase.Battle || paused;
        if(paused)return;
        float dt=Mathf.Min(Time.deltaTime,.04f);
        for(int i=sparks.Count-1;i>=0;i--) { Spark s=sparks[i]; s.p+=s.v*dt; s.life-=dt; if(s.life<=0)sparks.RemoveAt(i); }
        if(phase!=Phase.Battle)return;
        Vector2 move=new Vector2((Input.GetKey(KeyCode.D)||Input.GetKey(KeyCode.RightArrow)?1:0)-(Input.GetKey(KeyCode.A)||Input.GetKey(KeyCode.LeftArrow)?1:0),(Input.GetKey(KeyCode.S)||Input.GetKey(KeyCode.DownArrow)?1:0)-(Input.GetKey(KeyCode.W)||Input.GetKey(KeyCode.UpArrow)?1:0));
        TickBattle(dt,move,Input.GetMouseButton(0) && mouse.y>112 && mouse.y<660,Input.GetKeyDown(KeyCode.Space));
    }
    void TickBattle(float dt,Vector2 move,bool shoot,bool dash)
    {
        elapsed+=dt; waveBanner-=dt; immunity-=dt; fireClock-=dt; dashClock-=dt; dashTime-=dt;
        if(dash && dashClock<=0 && move.sqrMagnitude>0) { dashClock=2; dashTime=.15f; immunity=.23f; if(playerView!=null)playerView.PlayAction("Dash",2); }
        player+=move.normalized*(dashTime>0?850:260)*dt; player.x=Mathf.Clamp(player.x,42,1238); player.y=Mathf.Clamp(player.y,136,646);
        if(shoot && fireClock<=0)Fire();
        spawnClock-=dt;
        if(remaining>0 && spawnClock<=0) { Spawn(); remaining--; spawnClock=Mathf.Max(.34f,1.05f-wave*.1f); }
        for(int i=enemies.Count-1;i>=0;i--)
        {
            Enemy e=enemies[i]; Vector2 target=e.kind==1?player:hive; Vector2 delta=target-e.p;
            e.p+=delta.normalized*e.speed*dt; e.attack-=dt;
            if(e.kind==2 && e.attack<=0 && delta.magnitude<550) { shots.Add(new Shot{p=e.p,velocity=(player-e.p).normalized*230,life=4,hostile=true}); e.attack=2.8f; Animate(e,"Shoot",1); }
            if(e.kind==1 && Vector2.Distance(e.p,player)<38)
            {
                Explosion(e.p,new Color(1,.48f,.18f)); DamagePlayer(22);
                if(Vector2.Distance(e.p,hive)<95)DamageHive(18); enemies.RemoveAt(i); continue;
            }
            if(Vector2.Distance(e.p,player)<30)DamagePlayer(12);
            if(Vector2.Distance(e.p,hive)<48) { DamageHive(e.kind==1?18:10); Explosion(e.p,Honey); enemies.RemoveAt(i); }
        }
        for(int i=shots.Count-1;i>=0;i--)
        {
            Shot s=shots[i]; Vector2 before=s.p; s.p+=s.velocity*dt; s.life-=dt; bool consumed=false;
            if(s.hostile) { if(SegmentDistance(player,before,s.p)<20) { DamagePlayer(14); consumed=true; } }
            else
            {
                int nearest=-1; float first=float.PositiveInfinity;
                for(int j=0;j<enemies.Count;j++) { Vector2 e=enemies[j].p; float t=BeeGuardRules.ImpactTime(e.x,e.y,before.x,before.y,s.p.x,s.p.y,25); if(t<first) { first=t; nearest=j; } }
                if(nearest>=0) { Enemy e=enemies[nearest]; e.hp-=BeeGuardRules.Damage(damageLevel); consumed=true; Burst(Vector2.Lerp(before,s.p,first),Honey); Animate(e,"Hit",3); if(e.hp<=0)Kill(nearest); }
            }
            if(consumed || s.life<=0 || s.p.x<0 || s.p.x>1280 || s.p.y<115 || s.p.y>660)shots.RemoveAt(i);
        }
        for(int i=loot.Count-1;i>=0;i--) { Loot l=loot[i]; l.life-=dt; float distance=Vector2.Distance(l.p,player); if(distance<110)l.p=Vector2.MoveTowards(l.p,player,320*dt); if(distance<26) { if(l.heal)hp=Mathf.Min(100,hp+15); else coins+=8; Burst(l.p,l.heal?Mint:Honey); loot.RemoveAt(i); Sound(rewardSound); } else if(l.life<=0)loot.RemoveAt(i); }
        if(hp<=0 || hiveHP<=0)Finish(false);
        else if(remaining==0 && enemies.Count==0)
        {
            foreach(Loot l in loot) { if(l.heal)hp=Mathf.Min(100,hp+15); else coins+=8; } loot.Clear();
            coins+=35+wave*10; shots.Clear(); Sound(rewardSound); if(wave>=FinalWave)Finish(true); else phase=Phase.Shop;
        }
    }
    static float SegmentDistance(Vector2 p,Vector2 a,Vector2 b) { return BeeGuardRules.SegmentDistance(p.x,p.y,a.x,a.y,b.x,b.y); }
    void Fire()
    {
        Vector2 aim=(mouse-player).normalized; if(aim.sqrMagnitude<.1f) aim=Vector2.up;
        shots.Add(new Shot{p=player+aim*26,velocity=aim*720,life=1.8f}); fireClock=BeeGuardRules.FireInterval(rateLevel); if(playerView!=null)playerView.PlayAction("Shoot",1); Sound(shootSound);
    }
    void Spawn()
    {
        int side=UnityEngine.Random.Range(0,4); Vector2 p=side==0?new Vector2(22,UnityEngine.Random.Range(155,630)):side==1?new Vector2(1258,UnityEngine.Random.Range(155,630)):new Vector2(UnityEngine.Random.Range(45,1235),side==2?130:645);
        int kind=wave>=3 && remaining%4==0?2:(remaining%3==0?1:0);
        enemies.Add(new Enemy{p=p,kind=kind,hp=(kind==2?85:kind==1?35:48)+wave*7,speed=(kind==1?100:kind==2?35:52)+wave*5,attack=2});
    }
    void Kill(int index) { Enemy e=enemies[index]; kills++; coins+=e.kind==2?18:10; loot.Add(new Loot{p=e.p,heal=kills%7==0}); if(e.kind==1)Explosion(e.p,new Color(1,.48f,.18f)); else Burst(e.p,Honey); enemies.RemoveAt(index); }
    void Burst(Vector2 p,Color c) { for(int i=0;i<9;i++) sparks.Add(new Spark{p=p,v=UnityEngine.Random.insideUnitCircle*120,life=.4f,color=c}); }
    void Finish(bool won) { SetPaused(false); phase=won?Phase.Victory:Phase.Defeat; shots.Clear(); if(!won) { if(hp<=0 && playerView!=null)playerView.Fall(); if(hiveHP<=0 && hiveView!=null)hiveView.Fall(); } if(!runningChecks && kills>best) { best=kills; PlayerPrefs.SetInt("BeeGuardBest",best); PlayerPrefs.Save(); } }
    bool Buy(int type)
    {
        if(phase!=Phase.Shop)return false;
        bool success=BeeGuardRules.TryBuy(type,ref coins,ref damageLevel,ref rateLevel,ref hp,ref hiveHP);
        if(success) { Sound(rewardSound); if(type==2 && playerView!=null)playerView.PlayAction("Hit",1); if(type==3 && hiveView!=null)hiveView.PlayAction("HivePulse",1); }
        return success;
    }
    void Styles()
    {
        if(label!=null) return;
        Font uiFont=Resources.Load<Font>("Fonts/DejaVuSans");
        label=new GUIStyle(GUI.skin.label){font=uiFont,fontSize=20,fontStyle=FontStyle.Bold}; label.normal.textColor=Color.white;
        heading=new GUIStyle(label){fontSize=48}; small=new GUIStyle(label){fontSize=15,fontStyle=FontStyle.Normal}; small.normal.textColor=new Color(.66f,.77f,.79f);
        button=new GUIStyle(GUI.skin.button){font=uiFont,fontSize=18,fontStyle=FontStyle.Bold,alignment=TextAnchor.MiddleCenter,border=new RectOffset(0,0,0,0)};
        button.normal.background=white; button.hover.background=white; button.active.background=white;
        button.normal.textColor=Ink; button.hover.textColor=Ink; button.active.textColor=Ink;
    }
    void Box(float x,float y,float w,float h,Color c) { GUI.color=c; GUI.DrawTexture(new Rect(x,y,w,h),white); GUI.color=Color.white; }
    void Circle(Vector2 p,float radius,Color c) { GUI.color=c; GUI.DrawTexture(new Rect(p.x-radius,p.y-radius,radius*2,radius*2),disc); GUI.color=Color.white; }
    void Text(float x,float y,string value,GUIStyle style=null) { GUI.Label(new Rect(x,y,1000,65),value,style??label); }
    bool Button(float x,float y,float w,string text,bool enabled=true) { GUI.enabled=enabled; GUI.backgroundColor=Honey; bool clicked=GUI.Button(new Rect(x,y,w,48),text,button); GUI.backgroundColor=Color.white; GUI.enabled=true; return clicked; }
    void Bar(float x,float y,float width,float value,Color c) { Box(x,y,width,8,new Color(.1f,.18f,.21f)); Box(x,y,width*Mathf.Clamp01(value/100),8,c); }
    // Only HUD is drawn here. All world art comes from imported sprites.
    void Garden()
    {
        Box(0,0,1280,112,Ink); Box(0,660,1280,60,Ink);
        if(phase==Phase.Menu) return;
        Text(592,441,"LÀNG ONG",small);
        foreach(Enemy e in enemies) Bar(e.p.x-20,e.p.y-42,40,e.hp/(e.kind==2?85+wave*7:e.kind==1?35+wave*7:48+wave*7)*100,new Color(.94f,.4f,.47f));
        if(phase==Phase.Battle && !paused) { Circle(mouse,9,new Color(1,1,1,.25f)); Circle(mouse,3,Honey); }
    }
    void OnGUI()
    {
        Styles(); GUI.matrix=Matrix4x4.Scale(new Vector3(Screen.width/1280f,Screen.height/720f,1)); Garden();
        Text(30,18,"BEE / GUARD",new GUIStyle(heading){fontSize=30}); Text(31,61,"BẢO VỆ NGÔI LÀNG MẬT ONG",small);
        if(phase!=Phase.Menu)
        {
            Text(395,22,"CHIẾN BINH  "+Mathf.CeilToInt(Mathf.Max(0,hp))); Bar(395,62,180,hp,Mint);
            Text(615,22,"LÀNG ONG  "+Mathf.CeilToInt(Mathf.Max(0,hiveHP))); Bar(615,62,180,hiveHP,Honey);
            Text(835,22,"ĐỢT "+wave+" / "+FinalWave); Text(1035,22,coins+"  MẬT");
            Text(835,62,"Còn lại: "+(remaining+enemies.Count),small); Text(1035,62,"Hạ gục: "+kills,small);
        }
        Text(30,679,"WASD / Mũi tên: di chuyển    •    Chuột trái: bắn    •    Space: lướt    •    Esc: tạm dừng    •    M: âm thanh",small);
        if(phase==Phase.Battle && !paused) { Text(32,124,"BẢO VỆ TỔ ONG",small); if(waveBanner>0)Text(500,130,"ĐỢT "+wave+" / "+FinalWave,new GUIStyle(heading){fontSize=32}); Text(920,623,dashClock<=0?"LƯỚT SẴN SÀNG":"Lướt: "+dashClock.ToString("0.0")+"s",small); }
        if(phase==Phase.Menu)
        {
            Box(260,170,760,385,new Color(.035f,.07f,.10f,.96f)); Text(314,195,"NHỮNG CHIẾN BINH BEE",heading);
            Text(315,274,"Ngôi làng yên bình đang bị quân ong bóng tối tấn công.");
            Text(315,315,"Giữ tổ ong qua 5 đợt • Né bom • Thu mật • Nâng cấp súng",small);
            Text(315,350,"Ong tím tấn công làng. Ong đỏ mang bom truy đuổi bạn.",small);
            Text(315,380,"Giữa các đợt, dùng mật mua trang bị và sửa chữa tổ ong.",small);
            if(Button(315,440,330,"BẮT ĐẦU BẢO VỆ")) StartGame(); Text(690,450,"Kỷ lục: "+best,small);
            if(Button(315,500,330,"THOÁT GAME"))Application.Quit();
        }
        else if(phase==Phase.Shop)
        {
            Box(250,155,780,455,new Color(.035f,.07f,.10f,.98f)); Text(290,174,"XƯỞNG MẬT ONG",heading); Text(292,240,"Hoàn thành đợt "+wave+". Chọn nâng cấp trước đợt tiếp theo.",small);
            Text(295,288,"Sát thương • Cấp "+damageLevel+"/4"); if(Button(695,282,290,damageLevel>=4?"ĐÃ TỐI ĐA":(45+damageLevel*30)+" MẬT  /  NÂNG CẤP",damageLevel<4 && coins>=45+damageLevel*30)) Buy(0);
            Text(295,349,"Tốc độ bắn • Cấp "+rateLevel+"/4"); if(Button(695,343,290,rateLevel>=4?"ĐÃ TỐI ĐA":(45+rateLevel*30)+" MẬT  /  NÂNG CẤP",rateLevel<4 && coins>=45+rateLevel*30)) Buy(1);
            if(Button(295,412,325,"HỒI 40 MÁU  /  35 MẬT",coins>=35 && hp<100)) Buy(2);
            if(Button(655,412,330,"SỬA TỔ +35  /  40 MẬT",coins>=40 && hiveHP<100)) Buy(3);
            if(Button(295,505,690,"SẴN SÀNG — ĐỢT "+(wave+1))) NextWave();
        }
        else if(paused || phase==Phase.Victory || phase==Phase.Defeat)
        {
            Box(325,200,630,320,new Color(.035f,.07f,.10f,.97f)); Text(365,230,paused?"TẠM DỪNG":phase==Phase.Victory?"NGÔI LÀNG AN TOÀN!":"LÀNG ONG THẤT THỦ",new GUIStyle(heading){fontSize=36});
            Text(367,305,"Hạ gục: "+kills+"   •   Mật: "+coins+"   •   Kỷ lục: "+best);
            if(Button(365,375,550,paused?"TIẾP TỤC":"CHƠI LẠI")) { if(paused) SetPaused(false); else StartGame(); }
            if(Button(365,438,550,"VỀ TRANG CHỦ")) { SetPaused(false); phase=Phase.Menu; enemies.Clear(); shots.Clear(); loot.Clear(); sparks.Clear(); ClearSpriteViews(); }
        }
    }
    // Run in a licensed Unity editor or player. No assertions are marked as passed before execution.
    public void RunSmoke()
    {
        runningChecks=true;
        bool cli=Array.IndexOf(Environment.GetCommandLineArgs(),"--bee-smoke")>=0;
        try {
            StartGame(); ValidateAnimations(); if(wave!=1 || remaining!=8 || hp!=100)throw new Exception("Initial state");
            Spawn(); enemies[0].hp=1; Kill(0); if(kills!=1 || coins!=10 || enemies.Count!=0)throw new Exception("Kill/reward");
            coins=200; phase=Phase.Shop; if(!Buy(0) || damageLevel!=1 || coins!=155)throw new Exception("Upgrade");
            hp=60; if(!Buy(2) || hp!=100 || coins!=120)throw new Exception("Healing");
            phase=Phase.Battle; if(Buy(0))throw new Exception("Shop outside phase");
            mouse=player+Vector2.right*100; Fire(); if(shots.Count!=1 || shots[0].velocity.x<700)throw new Exception("Shooting");
            StartGame(); spawnClock=100; remaining=1; TickBattle(.01f,new Vector2(1,1),false,false);
            if(Mathf.Abs(Vector2.Distance(player,new Vector2(640,510))-2.6f)>.01f)throw new Exception("Normalized movement");
            TickBattle(.01f,Vector2.right,false,true); if(dashClock<=0 || immunity<=0)throw new Exception("Dash");
            StartGame(); remaining=0; enemies.Clear(); TickBattle(.01f,Vector2.zero,false,false); if(phase!=Phase.Shop || coins!=45)throw new Exception("Wave completion");
            StartGame(); wave=5; remaining=0; enemies.Clear(); TickBattle(.01f,Vector2.zero,false,false); if(phase!=Phase.Victory)throw new Exception("Victory");
            StartGame(); hp=0; TickBattle(.01f,Vector2.zero,false,false); if(phase!=Phase.Defeat)throw new Exception("Defeat");
            StartGame(); if(coins!=0 || hp!=100 || hiveHP!=100 || wave!=1)throw new Exception("Restart");
            Debug.Log("BEE_SMOKE_PASS: state, rewards, shop guard, movement, dash, projectiles, waves, victory, defeat, restart");
            if(cli)Application.Quit(0); else { phase=Phase.Menu; ClearSpriteViews(); runningChecks=false; }
        } catch(Exception ex) { runningChecks=false; Debug.LogError("BEE_SMOKE_FAIL: "+ex); if(cli)Application.Quit(1); }
    }
    void OnDestroy() { Time.timeScale=1; Cursor.visible=true; if(disc!=null) Destroy(disc); if(shootSound!=null) Destroy(shootSound); if(hitSound!=null) Destroy(hitSound); if(rewardSound!=null) Destroy(rewardSound); }
}
