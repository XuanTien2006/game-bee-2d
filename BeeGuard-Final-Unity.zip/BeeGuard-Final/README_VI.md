# Bee Guard — Bản game có hoạt ảnh

Game phòng thủ 2D một người chơi, gồm một đấu trường, năm đợt địch, ba loại quái, bắn đạn, ong mang bom tự nổ khi áp sát, vật phẩm, nâng cấp súng, sửa tổ, tạm dừng, âm thanh và lưu kỷ lục.

## Chơi ngay trên Linux

Tải gói BeeGuard-Linux.zip, giải nén, mở Start_BeeGuard.sh hoặc BeeGuard.x86_64. Nếu trình quản lý tệp không cho thực thi, mở terminal tại thư mục đó và chạy:

```sh
chmod +x Start_BeeGuard.sh BeeGuard.x86_64
./Start_BeeGuard.sh
```

Giữ nguyên BeeGuard_Data, UnityPlayer.so và các tệp đi kèm bên cạnh file chạy. Đây là bản Linux x86_64, không phải file exe cho Windows.

## Mở và sửa trong Unity

1. Giải nén BeeGuard-Final-Unity.zip vào thư mục mới.
2. Unity Hub → Add project from disk → chọn BeeGuard-Final chứa Assets, Packages và ProjectSettings.
3. Dùng Unity 6000.6.9f1 hoặc phiên bản tương thích; đợi import, mở Assets/Scenes/BeeGuard.unity rồi Play.
4. Hierarchy có Garden Background, Village Hive, Player, nhóm Enemy Preview và Game Manager. Quái mẫu ẩn khi chơi; quái thật được tạo bên dưới Runtime • Enemies Bullets Loot Effects.
5. Chọn đối tượng và bấm F trong Scene để lấy nét. Chọn Visual để xem ảnh; chọn đối tượng gốc để xem Animation, BeeGuardActor và Collider2D.

## Điều khiển và luật chơi

WASD hoặc mũi tên để di chuyển; chuột để ngắm; giữ chuột trái để bắn; Space để lướt theo hướng đang đi, hồi chiêu 2 giây; Esc tạm dừng; M bật/tắt âm thanh.

Bảo vệ cả chiến binh và tổ ong. Một trong hai hết máu là thua. Hạ hết địch trong mỗi đợt để vào cửa hàng; qua năm đợt là thắng. Ong tím tiến vào tổ, ong đỏ mang bom đuổi người chơi và tự nổ khi áp sát, ong giáp xuất hiện từ đợt 3 và bắn đạn. Thu mật và vật phẩm hồi máu; dùng mật nâng sát thương, tốc độ bắn, hồi máu hoặc sửa tổ. Hai nâng cấp súng tối đa cấp 4. Giao dịch chỉ được thực hiện trong cửa hàng.

## Chín clip hoạt ảnh

Các file .anim nằm ở Assets/Resources/Animations:

- Fly — bay nhấp nhô, nghiêng và co giãn nhẹ, phát lặp.
- Shoot — giật lùi khi bắn rồi trở lại trạng thái bay.
- Hit — co giãn và lắc khi nhận sát thương, kết hợp đổi màu.
- Dash — kéo dài nhân vật trong lúc lướt.
- Death — xoay, rơi, thu nhỏ và mờ dần.
- PickupFloat — vật phẩm nảy và đổi kích thước nhẹ.
- Collect — vật phẩm bay lên, nở rồi biến mất khi được thu.
- HivePulse — tổ ong phồng nhẹ theo chu kỳ.
- Explosion — vụ nổ nở ra và mờ dần.

Đây là hoạt ảnh keyframe trên Transform và màu của sprite, dùng Animation component của Unity; chưa có bộ ảnh thay đổi tư thế từng khung hình hoặc khung xương cánh riêng. Visual là đối tượng con để hoạt ảnh không làm thay đổi tọa độ va chạm của đối tượng gốc.

Để xem timeline trong Unity: mở prefab → chọn đối tượng gốc → Window → Animation → Animation → chọn clip. Để xem nhanh ngoài Unity: mở Preview_Animations.html bằng trình duyệt, giữ nguyên thư mục Assets đi kèm. Trang xem trước sử dụng cùng dữ liệu keyframe, không phải bản WebGL của game.

## Cấu trúc source

- BeeGuardGame.cs — nhập liệu, đợt địch, giao chiến, cửa hàng và HUD.
- BeeGuardGame.Sprites.cs — tạo prefab, đồng bộ đối tượng, quản lý hiệu ứng.
- BeeGuardActor.cs — phát clip, nhận sát thương, hồi trạng thái và hiệu ứng bị hạ.
- BeeGuardRules.cs — công thức đợt địch, nâng cấp và va chạm quét của đạn.
- BeeGuardGame.Validation.cs — kiểm tra nhanh và chụp màn hình khi chạy với tham số QA.
- Assets/Editor/BeeGuardAnimationBuilder.cs — dựng lại clip bằng API Unity.
- Assets/Editor/BeeGuardBuilder.cs — dựng prefab, scene và xuất bản.

Tất cả ảnh nhân vật, quái, tổ, nền là tài nguyên PNG riêng; có 12 prefab. UI chữ, nút, thanh máu vẫn dùng OnGUI. TTF DejaVu Sans được đóng gói để chữ tiếng Việt và nút nhất quán; giấy phép nằm trong Assets/Resources/Fonts.

## Dựng lại và xuất bản

Bee Guard → Rebuild animation clips tạo lại clip. Rebuild sprite prefabs tạo lại prefab. Prepare scene dựng lại scene mẫu; lưu thay đổi riêng trước khi chạy vì đây là lệnh tạo scene mới.

Build Linux bằng command line với -executeMethod BeeGuardBuilder.BuildLinux. Build Windows bằng -executeMethod BeeGuardBuilder.BuildWindows sau khi cài Windows Build Support qua Unity Hub. Có thể xuất thủ công từ Build Profiles. Bản Windows chưa được build hoặc kiểm thử trong lần bàn giao này.

## Kiểm tra

Xem VALIDATION.md để biết kết quả thực tế và giới hạn. Trong Play Mode, menu Bee Guard → Run gameplay checks in Play Mode chạy bài kiểm tra trạng thái và đưa game về Menu. Bài này đặt lại trận đang chơi.

Có thể chạy bản độc lập với --bee-smoke -batchmode -nographics để kiểm tra logic và sample clip. Tham số --bee-visual-check chụp các màn hình bằng những trạng thái kiểm thử được thiết lập sẵn; chạy có đồ họa, không dùng -batchmode/-nographics. Thư mục ảnh nhận qua biến BEE_SCREENSHOT_DIR.

## Giới hạn và nguồn hình

Bản này hoàn thiện phạm vi một trận phòng thủ năm đợt; chưa có multiplayer, nhiều bản đồ hoặc điều khiển cảm ứng. Collider2D hiện giúp quan sát vùng đối tượng trong Scene; sát thương dùng phép tính hình học ở BeeGuardRules, không dùng callback vật lý OnTriggerEnter2D. Di chuyển, tốc độ và bán kính va chạm gameplay cần chỉnh trong mã để khớp khi đổi hình.

Bộ hình chính được tạo bằng AI qua image_gen tích hợp; không mô tả là tự vẽ tay khi thuyết trình. ART_PROMPTS.md lưu prompt tạo ảnh. Các icon đơn giản và hiệu ứng nổ được tạo thành PNG riêng từ hình học.

Báo cáo Word trước đó mô tả prototype cũ. Khi nộp đồ án với bản này, cần thay phần đồ họa/hoạt ảnh và kết quả kiểm thử bằng nội dung ở đây, đồng thời dùng ảnh chạy thật trong Screenshots. Những ảnh đó là giao diện bản chạy Unity ở trạng thái QA được thiết lập sẵn, không chứng minh đã chơi thủ công hết năm đợt.
