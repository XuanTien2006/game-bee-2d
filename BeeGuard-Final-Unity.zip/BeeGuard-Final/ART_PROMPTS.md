# Art prompt set

Method: built-in image_gen, six separate generation calls. No CLI fallback. Character/building PNG alpha preserved unchanged. Small utility icons were authored separately as simple native graphics.

## PlayerBee
A single friendly honeybee warrior game sprite for a top-down 2D Unity garden defense game. Golden yellow and dark brown striped round body, expressive eyes, two translucent pale blue wings, tiny leaf-green scarf and a small wooden honey blaster pointing right. Three-quarter overhead view, faces right. Hand-painted cartoon game art, crisp dark outlines, soft cel shading, readable at 64 pixels. Centered full body, generous transparent padding, no ground, no shadow, no text, no border, no extra objects. Square canvas. Genuine transparent background.

## EnemyBee
A single enemy purple hornet game sprite for a top-down 2D Unity garden defense game. Violet and charcoal striped stout round body, mischievous angry eyes, two pale blue wings. Three-quarter overhead view, faces right. Hand-painted cartoon art, crisp dark outlines, soft cel shading, readable at 64 pixels. Centered full body, generous transparent padding, no ground, no shadow, no text, no border, no extra objects. Square canvas. Genuine transparent background.

## BomberBee
A single red bomber hornet game sprite for a top-down 2D Unity garden defense game. Coral red and dark brown striped round body, determined eyes, two translucent pale blue wings, one clearly visible small black cartoon bomb carried below abdomen with short unlit fuse. Three-quarter overhead view, faces right. Hand-painted cartoon art, crisp dark outlines, soft cel shading, readable at 64 pixels. Centered full body including bomb, generous transparent padding, no ground, no shadow, no text, no border. Square canvas. Genuine transparent background.

## ArmoredBee
A single armored teal and purple hornet game sprite for a top-down 2D Unity garden defense game. Stout purple bee wearing teal beetle-shell shoulder armor and a tiny metal helmet, angry eyes, pale blue wings, small honey cannon points right. Three-quarter overhead view, faces right. Hand-painted cartoon art, crisp dark outlines, soft cel shading, readable at 64 pixels. Centered full body, generous transparent padding, no ground, no shadow, no text, no border. Square canvas. Genuine transparent background.

## Hive
A single honeybee village hive building game sprite for a top-down 2D Unity garden defense game. Charming golden woven beehive cottage, rounded tiered honey straw roof, dark arched entrance facing bottom, tiny leaves, honeycomb trim, a little amber honey pot beside doorway. Three-quarter overhead view matching top-down game characters. Hand-painted cartoon art, crisp dark outlines, soft cel shading, readable at 128 pixels. Centered entire building, generous transparent padding, no ground plane, no cast shadow, no text, no border. Square canvas. Genuine transparent background.

## GardenBackground
A finished environment background for a top-down 2D cartoon honeybee garden defense game, wide 16:9 landscape composition. Overhead camera looking down at a lush meadow clearing with a large uncluttered playable oval of muted moss green grass covering the central 80 percent, subtle worn grass paths from four edges towards center, dense decorative flowers clover leaves ferns stones and mushrooms only around the perimeter. Warm inviting storybook hand-painted game art, rich but muted greens, small touches of yellow white pink flowers, clean soft outlines, polished casual 2D game background. Center must remain empty grass for placing a beehive and combat units. No beehive, no bees, no characters, no weapons, no text, no UI, no labels, no watermark. Flat overhead perspective, no horizon, no sky. Opaque background.
