# Thay đổi của bản hoạt ảnh

- Thêm 9 AnimationClip và BeeGuardActor trên mỗi prefab, tách Visual khỏi root.
- Bay, phản lực bắn, trúng đòn, lướt, bị hạ, vật phẩm, tổ ong và nổ.
- Ong mang bom tự nổ khi tới gần người chơi; tổ gần vùng nổ có thể bị ảnh hưởng.
- Đạn chọn mục tiêu va chạm đầu tiên dọc đường bay; hết đạn khi trúng người kể cả đang miễn sát thương.
- Chỉ cho phép mua đồ trong Shop; kiểm tra tiền, trần nâng cấp và giới hạn hồi phục.
- Tạm dừng đồng bộ logic và hoạt ảnh bằng Time.timeScale.
- Dọn đối tượng và khôi phục hoạt ảnh/máu/tài nguyên khi chơi lại.
- Hiện thông báo đợt, nút thoát game; đóng gói font DejaVu Sans và làm rõ màu nút.
- Thêm kiểm tra quy tắc, runtime smoke, sample animation, ảnh màn hình thật và trình xem hoạt ảnh offline.
- Build Linux; cung cấp phương thức build Windows khi có module tương ứng.
