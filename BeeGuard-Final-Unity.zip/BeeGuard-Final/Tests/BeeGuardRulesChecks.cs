using System;
public static class BeeGuardRulesChecks
{
    static int checks;
    static void Check(bool value,string name) { checks++; if(!value)throw new Exception(name); }
    static void Near(float a,float b,string name,float epsilon=.0001f) { Check(Math.Abs(a-b)<epsilon,name); }
    public static int Main()
    {
        int sum=0; for(int w=1;w<=5;w++)sum+=BeeGuardRules.EnemyCount(w); Check(sum==70,"Five waves total 70 enemies");
        bool threw=false;try{BeeGuardRules.EnemyCount(0);}catch(ArgumentOutOfRangeException){threw=true;}Check(threw,"Invalid wave rejected");
        Near(BeeGuardRules.SegmentDistance(5,3,0,0,10,0),3,"Perpendicular distance");
        Near(BeeGuardRules.SegmentDistance(15,0,0,0,10,0),5,"Segment end clamp");
        Near(BeeGuardRules.SegmentDistance(3,4,0,0,0,0),5,"Zero length segment");
        Near(BeeGuardRules.ImpactTime(5,0,0,0,10,0,1),.4f,"Entry time");
        Near(BeeGuardRules.ImpactTime(5,1,0,0,10,0,1),.5f,"Tangential impact");
        Near(BeeGuardRules.ImpactTime(0,0,0,0,10,0,1),0,"Starts inside target");
        Check(float.IsPositiveInfinity(BeeGuardRules.ImpactTime(5,2,0,0,10,0,1)),"Miss");
        Check(float.IsPositiveInfinity(BeeGuardRules.ImpactTime(-5,0,0,0,10,0,1)),"Target behind projectile");
        Check(BeeGuardRules.ImpactTime(3,0,0,0,20,0,1)<BeeGuardRules.ImpactTime(8,0,0,0,20,0,1),"Nearest target before farther target");
        int coins=360,damage=0,rate=0;float hp=100,hive=100;
        for(int level=0;level<4;level++)Check(BeeGuardRules.TryBuy(0,ref coins,ref damage,ref rate,ref hp,ref hive),"Damage upgrade "+level);
        Check(coins==0 && damage==4,"Four upgrades cost exactly 360");coins=1000;
        Check(!BeeGuardRules.TryBuy(0,ref coins,ref damage,ref rate,ref hp,ref hive) && coins==1000,"Cap blocks charge");
        Check(!BeeGuardRules.TryBuy(2,ref coins,ref damage,ref rate,ref hp,ref hive),"Full health purchase blocked");
        hp=85;Check(BeeGuardRules.TryBuy(2,ref coins,ref damage,ref rate,ref hp,ref hive) && hp==100 && coins==965,"Heal clamped and charged");
        hive=80;Check(BeeGuardRules.TryBuy(3,ref coins,ref damage,ref rate,ref hp,ref hive) && hive==100 && coins==925,"Repair clamped and charged");
        coins=34;hp=40;Check(!BeeGuardRules.TryBuy(2,ref coins,ref damage,ref rate,ref hp,ref hive) && coins==34 && hp==40,"Insufficient currency leaves state intact");
        Check(!BeeGuardRules.TryBuy(99,ref coins,ref damage,ref rate,ref hp,ref hive),"Invalid shop choice blocked");
        for(int i=0;i<4;i++)Check(BeeGuardRules.FireInterval(i+1)<BeeGuardRules.FireInterval(i),"Fire rate increases "+i);
        Check(BeeGuardRules.Damage(4)==72,"Maximum damage");
        var random=new Random(27);
        for(int i=0;i<1000;i++)
        {
            float ax=(float)random.NextDouble()*100,ay=(float)random.NextDouble()*100,bx=(float)random.NextDouble()*100,by=(float)random.NextDouble()*100;
            float px=(float)random.NextDouble()*100,py=(float)random.NextDouble()*100,r=3+(float)random.NextDouble()*12;
            float t=BeeGuardRules.ImpactTime(px,py,ax,ay,bx,by,r);
            if(!float.IsPositiveInfinity(t)) { float dx=ax+(bx-ax)*t-px,dy=ay+(by-ay)*t-py;Check(t>=0 && t<=1 && dx*dx+dy*dy<=r*r+.02f,"Random impact geometry "+i); }
            else
            {
                bool sampleHit=false;for(int k=0;k<=100;k++) { float q=k/100f,dx=ax+(bx-ax)*q-px,dy=ay+(by-ay)*q-py;if(dx*dx+dy*dy<r*r-.02f)sampleHit=true; }
                Check(!sampleHit,"No swept misses "+i);
            }
        }
        Console.WriteLine("BEE_RULES_PASS: "+checks+" assertions (wave counts, shop, upgrades, healing, collision and 1000 randomized sweeps)");return 0;
    }
}
